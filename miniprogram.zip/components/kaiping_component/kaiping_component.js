Component({
    properties: {
        imagepath: {
            type: String,
            value: "../../图床/logo.png"
        },
        second: {
            type: Number,
            value: "5"
        }
    },
    data: {
        timer: null
    },
    lifetimes: {
        created: function () {

        },
        attached: function () {
            let secondTime = this.data.second;
            let that = this;
            const timer = setInterval(function () {
                let nowSecond = --that.data.second;
                if (nowSecond <= 0) {
                    clearInterval(timer);
                    that.hideKaiping();
                }
                console.log(nowSecond);
                that.setData({
                    second: nowSecond
                });
            }, 1000);
            this.setData({
                timer: timer
            });
        }
    },
    methods: {
        hideKaiping: function () {
            this.triggerEvent("hide");
        },
        skipAnimation: function () {
            this.hideKaiping();
            let timer = this.data.timer;
            if (timer) {
                clearInterval(timer);
            }
        }
    }
})